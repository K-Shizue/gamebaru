//=============================================================================
// BB_CustomSaveWindow.js
// Copyright (c) 2016 BB ENTERTAINMENT
//=============================================================================

/*:
* @plugindesc セーブウインドウ改造プラグイン
* @author ビービー
* 
* 
* @param OutsideFrameColor
* @desc 外枠の色を指定（テキストカラー0～31）
* デフォルト：0
* @default 0
* 
* @param OutsideFrameOpacity
* @desc 外枠の透明度を指定（0～255）
* デフォルト：64
* @default 64
* 
* @param InsideFrameColor
* @desc 内枠の色を指定（テキストカラー0～31）
* デフォルト：0
* @default 0
* 
* @param InsideFrameOpacity
* @desc 内枠の透明度を指定（0～255）
* デフォルト：64
* @default 64
* 
* @param MaxItem
* @desc 内枠の数を指定（1～4）
* デフォルト：4（0で非表示）
* @default 4
* 
* @param Item0
* @desc ファイルID右に表示される項目 0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* @default 1
* 
* @param Item0Length
* @desc ファイルID右に表示される項目の横幅（Item5(右上に表示される項目)に影響）
* @default 300
* 
* @param Item1title
* @desc 右下に表示される項目のタイトル
* デフォルト：プレイ時間
* @default プレイ時間
* 
* @param Item1
* @desc 右下に表示される項目  0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名
* 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* @default 2
* 
* @param Item2title
* @desc 中央右に表示される項目のタイトル
* デフォルト：現在地
* @default 現在地
* 
* @param Item2
* @desc 中央右に表示される項目  0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名
* 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* デフォルト：3
* @default 3
* 
* @param Item3title
* @desc 中央下に表示される項目のタイトル
* デフォルト：所持金
* @default 所持金
* 
* @param Item3
* @desc 中央下に表示される項  0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名
* 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* デフォルト：4
* @default 4
* 
* @param Item4title
* @desc 中央に表示される項目のタイトル
* デフォルト：セーブ回数
* @default セーブ回数
* 
* @param Item4
* @desc 中央に表示される項目  0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名
* 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* デフォルト：5
* @default 5
* 
* @param Item5
* @desc 右上に表示される項目  0=非表示 1=ﾀｲﾄﾙ 2=ﾌﾟﾚｲ時間 3=ﾏｯﾌﾟ名
* 4=所持金 5=ｾｰﾌﾞ回数 6=変数項1 7=変数項2 8=変数項3 9=変数項4
* デフォルト：6
* @default 6
* 
* @param ItemValue1
* @desc 変数項目1に入れる変数のID
* デフォルト：1
* @default 1
* 
* @param ItemValue2
* @desc 変数項目2に入れる変数のID
* デフォルト：2
* @default 2
* 
* @param ItemValue3
* @desc 変数項目3に入れる変数のID
* デフォルト：3
* @default 3
* 
* @param ItemValue4
* @desc 変数項目4に入れる変数のID
* デフォルト：4
* @default 4
* 
* @param ItemValue1unit
* @desc 変数項目1の単位
* デフォルト：無し
* @default 
* 
* @param ItemValue2unit
* @desc 変数項目2の単位
* デフォルト：無し
* @default 
* 
* @param ItemValue3unit
* @desc 変数項目3の単位
* デフォルト：無し
* @default 
* 
* @param ItemValue4unit
* @desc 変数項目4の単位
* デフォルト：無し
* @default 
* 
* @param TitleFramelength1
* @desc 項目1のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* @default 110
* 
* @param TitleFramelength2
* @desc 項目2のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* @default 110
* 
* @param TitleFramelength3
* @desc 項目3のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* @default 110
* 
* @param TitleFramelength4
* @desc 項目4のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* @default 110
* 
* @param CharacterPositionY
* @desc キャラクターグラフィックのy座標（下=6 中央=12 上=20）
* デフォルト：6
* @default 6
* 
* @param LevelPositionY
* @desc レベルのy座標（下=72 上=23）
* デフォルト：23
* @default 23
* 
* @param LevelOnOff
* @desc レベルを表示するかしないかを指定（0＝非表示、1＝表示）
* デフォルト：1
* @default 1
* 
* @help プラグインの説明
* 
* ■各パラメータの説明
* プラグイン内より少しだけ詳しくパラメータの説明をしていきます。
* 
* OutsideFrameColor
* 外枠の色をテキストカラーの0～31で指定できます。
* デフォルト：0
* 
* OutsideFrameOpacity
* 外枠の透明度を0～255の数値で指定できます（0＝透明、255＝不透明）
* デフォルト：64
* 
* InsideFrameColor
* 内枠の色をテキストカラーの0～31で指定できます。
* デフォルト：0
* 
* InsideFrameOpacity
* 内枠の透明度を0～255の数値で指定できます（0＝透明、255＝不透明）
* デフォルト：64
* 
* MaxItem
* 内枠の数を0から4のあいだで指定できます。
* デフォルト：4（0で非表示）
* 
* Item0
* ファイルID右に表示される項目を0～9の数字で指定します。
* 0＝非表示
* 1＝ゲームタイトル
* 2＝プレイ時間
* 3＝マップ名
* 4＝所持金（自動で通貨単位も表示されます）
* 5＝セーブ回数
* 6＝パラメータのItemValue1で指定した変数の値（パラメータのItemValue1unitで単位を指定できます）
* 7＝パラメータのItemValue2で指定した変数の値（パラメータのItemValue2unitで単位を指定できます）
* 8＝パラメータのItemValue3で指定した変数の値（パラメータのItemValue3unitで単位を指定できます）
* 9＝パラメータのItemValue4で指定した変数の値（パラメータのItemValue4unitで単位を指定できます）
* 
* Item0Length
* ファイルID右に表示される項目の横幅を指定できます。（Item5(右上に表示される項目)に影響）
* 指定したサイズより文字列の幅が大きい場合、指定したサイズに自動で文字幅が縮小されます。
* default 300
* 
* Item1title
* 右下に表示される項目のタイトルを好きな文字列で指定できます。
* デフォルト：プレイ時間
* 
* Item1
* 右下に表示される項目を0～9の数字で指定します。
* デフォルト：2
* 
* Item2title
* 中央右に表示される項目のタイトルを好きな文字列で指定できます。
* デフォルト：現在地
* 
* Item2
* 中央右に表示される項目を0～9の数字で指定します。
* デフォルト：3
* 
* Item3title
* 中央下に表示される項目のタイトルを好きな文字列で指定できます。
* デフォルト：所持金
* 
* Item3
* 中央下に表示される項を0～9の数字で指定します。
* デフォルト：4
* 
* Item4title
* 中央に表示される項目のタイトルを好きな文字列で指定できます。
* デフォルト：セーブ回数
* 
* Item4
* 中央に表示される項目を0～9の数字で指定します。
* デフォルト：5
* 
* Item5
* 右上に表示される項目を0～9の数字で指定します。
* デフォルト：6
* 
* ItemValue1
* 変数項目1に入れる変数のIDを指定します。
* デフォルト：1
* 
* ItemValue2
* 変数項目2に入れる変数のIDを指定します。
* デフォルト：2
* 
* ItemValue3
* 変数項目3に入れる変数のIDを指定します。
* デフォルト：3
* 
* ItemValue4
* 変数項目4に入れる変数のIDを指定します。
* デフォルト：4
* 
* ItemValue1unit
* 変数項目1の単位を指定します。
* デフォルト：無し
* 
* ItemValue2unit
* 変数項目2の単位を指定します。
* デフォルト：無し
* 
* ItemValue3unit
* 変数項目3の単位を指定します。
* デフォルト：無し
* 
* ItemValue4unit
* 変数項目4の単位を指定します。
* デフォルト：無し
* 
* TitleFramelength1
* 項目1のタイトル枠の横幅を0～274のあいだから指定します。
* 文字数*20+10で文字の幅と同じ幅の枠を描画できます
* 指定した枠幅より文字幅がはみ出る場合自動で文字幅が縮小されます。
* デフォルト：110（5文字）
* 
* TitleFramelength2
* 項目2のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* 
* TitleFramelength3
* 項目3のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* 
* TitleFramelength4
* 項目4のタイトル枠の横幅（文字数*20+10）(0～274)
* デフォルト：110
* 
* CharacterPositionY
* キャラクターグラフィックのy座標を指定します。
* 下の方に表示したい場合は6、中央あたりなら12 上の方なら20が目安です。
* デフォルト：6
* 
* LevelPositionY
* レベルのy座標を指定します。下の方なら72、上の方なら23が目安です。
* レベルの表示はキャラクターグラフィックより手前に表示されます。
* デフォルト：23
* 
* LevelOnOff
* レベルを表示するかしないかを指定（0＝非表示、1＝表示）
* デフォルト：1
* 
* 
* ■変数に文字列を代入する方法
* 変数に文字列を代入するには
* イベントコマンドの"タブ1"にある"ゲーム進行"内の"変数の操作"を実行し
* 代入したい変数を選び、代入にチェックを入れ
* スクリプトに書き込みます
* このとき　'　←この記号ではじめと終わりを挟むのを忘れないでください。
* （ ' ←この記号はキーボードが半角英数のときにshiftを押しながら７で打てます）
* 
* ■BB ENTERTAINMENT BLOGにて画像付きで解説しています。
* 記事：http://bb-entertainment-blog.blogspot.jp/2016/11/blog-post_27.html#more
* 
* バージョン：
* 1.0.2 2016/12/01 レベルの表示、非表示を切り替えるパラメータを追加
* 1.0.1 2016/11/29 ヘルプを追記
* 1.0.0 2016/11/27 初版
* 
* 利用規約：
* このプラグインは、MITライセンスのもとで公開されています。
* Copyright (c) 2016 BB ENTERTAINMENT
* Released under the MIT License.
* http://opensource.org/licenses/mit-license.php
* 
* コンタクト：
* BB ENTERTAINMENT Twitter: https://twitter.com/BB_ENTER/
* BB ENTERTAINMENT BLOG   : http://bb-entertainment-blog.blogspot.jp/
*/


(function() {
'use strict';
//-----------------------------------------------------------------------------
// プラグインパラメータ管理
//-----------------------------------------------------------------------------
var parameters = PluginManager.parameters('BB_CustomSaveWindow');
var insideFrameColor = Number(parameters['InsideFrameColor']);
var insideFrameOpacity = Number(parameters['InsideFrameOpacity']);
var outsideFrameColor = Number(parameters['OutsideFrameColor']);
var outsideFrameOpacity = Number(parameters['OutsideFrameOpacity']);
var BBSWMaxItem = Number(parameters['MaxItem']);
var item0 = Number(parameters['Item0']);
var item0Length = Number(parameters['Item0Length']);
var item_1_title = String(parameters['Item1title']);
var BBSWItem1 = Number(parameters['Item1']);
var item2Title = String(parameters['Item2title']);
var item2 = Number(parameters['Item2']);
var item_3_title = String(parameters['Item3title']);
var BBSWItem3 = Number(parameters['Item3']);
var item_4_title = String(parameters['Item4title']);
var BBSWItem4 = Number(parameters['Item4']);
var BBSWItem5 = Number(parameters['Item5']);
var itemValue1 = Number(parameters['ItemValue1']);
var itemValue2 = Number(parameters['ItemValue2']);
var itemValue3 = Number(parameters['ItemValue3']);
var itemValue4 = Number(parameters['ItemValue4']);
var BBSWV1u = String(parameters['ItemValue1unit']);
var BBSWV2u = String(parameters['ItemValue2unit']);
var BBSWV3u = String(parameters['ItemValue3unit']);
var BBSWV4u = String(parameters['ItemValue4unit']);
var titleFrameLength_1 = Number(parameters['TitleFramelength1']);
var titleFrameLength_2 = Number(parameters['TitleFramelength2']);
var titleFrameLength_3 = Number(parameters['TitleFramelength3']);
var titleFrameLength_4 = Number(parameters['TitleFramelength4']);
var charPosY = Number(parameters['CharacterPositionY']);
var levelPosY = Number(parameters['LevelPositionY']);
var levelOnOff = Number(parameters['LevelOnOff']);
//-----------------------------------------------------------------------------
// セーブデータに名前を定義
//-----------------------------------------------------------------------------

// Various parts of this script use the originalDrawText method set up in the edited rubi riru script
var oldDataManagerMakeSaveFileInfo = DataManager.makeSavefileInfo;
DataManager.makeSavefileInfo = function() {
   var info = {};
   info.globalId   = this._globalId;
   if($gameVariables.value(549) >= 2){
       info.title      = "Sylphy and the Sleepless Island " + " [" + $gameVariables.value(549) + " Week]";
   }
   else{
       info.title      = "Sylphy and the Sleepless Island";
   }
   info.characters = $gameParty.charactersForSavefile();
   info.faces      = $gameParty.facesForSavefile();
   info.playtime   = $gameSystem.playtimeText();
   info.timestamp  = Date.now();
//add--------------------------------------------------------------------------
   info.mapname    = $gameMap.displayName();
   info.gold       = $gameParty._gold;
   info.savecount  = $gameSystem._saveCount;
   info.value1     = $gameVariables.value(itemValue1);
   info.value2     = $gameVariables.value(itemValue2);
   info.value3     = $gameVariables.value(itemValue3);
   info.value4     = $gameVariables.value(itemValue4);
   info.level1 	= $gameParty.members()[0].level;
//-----------------------------------------------------------------------------
   return info;
};

var oldSaveFileListDrawItem = Window_SavefileList.prototype.drawItem;
Window_SavefileList.prototype.drawItem = function(index) {
   var id = index + 1;
   var valid = DataManager.isThisGameFile(id);
   var info = DataManager.loadSavefileInfo(id);
   var rect = this.itemRectForText(index);
//add--------------------------------------------------------------------------
   this.contents.fontSize = 20;
   this.contents.paintOpacity = insideFrameOpacity;
   this.contents.fillRect(rect.x - 5, rect.y + 2, rect.width + 10 + 30, 2, this.textColor(insideFrameColor));

   this.contents.fillRect(rect.x - 3, rect.y + 4, rect.width + 6 + 30, 28, this.textColor(insideFrameColor));
   this.contents.paintOpacity = outsideFrameOpacity;
   if (BBSWMaxItem >= 0) 
   {
   }
   if (BBSWMaxItem >= 1) {
       this.contents.fillRect(rect.x + 580, rect.y + 95, titleFrameLength_1, 26, this.textColor(outsideFrameColor));
       //^This affects the size of the area containing the text that says "Location"

       this.contents.fillRect(rect.x + 580, rect.y + 93, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 580, rect.y + 121, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 854 + 30, rect.y + 95, 2, 26, this.textColor(outsideFrameColor));

   } if (BBSWMaxItem >= 2) {
       this.contents.fillRect(rect.x + 580, rect.y + 44, titleFrameLength_2, 26, this.textColor(outsideFrameColor));
       //^This affects the size of the area containing the text that says "Play Time"
       
       this.contents.fillRect(rect.x + 580, rect.y + 42, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 580, rect.y + 70, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 854 + 30, rect.y + 44, 2, 26, this.textColor(outsideFrameColor));

   } if (BBSWMaxItem >= 3) {
       this.contents.fillRect(rect.x + 240, rect.y + 95, titleFrameLength_3, 26, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 240, rect.y + 93, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 240, rect.y + 121, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 514 + 30, rect.y + 95, 2, 26, this.textColor(outsideFrameColor));
   } if (BBSWMaxItem >= 4) {
       this.contents.fillRect(rect.x + 240, rect.y + 44, titleFrameLength_4, 26, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 240, rect.y + 42, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 240, rect.y + 70, 276 + 30, 2, this.textColor(outsideFrameColor));
       this.contents.fillRect(rect.x + 514 + 30, rect.y + 44, 2, 26, this.textColor(outsideFrameColor));
   }
   this.contents.paintOpacity = 255;
//-----------------------------------------------------------------------------
   this.resetTextColor();
   if (this._mode === 'load') {
       this.changePaintOpacity(valid);
   }

   this.drawFileId(id, rect.x, rect.y);
   if (info) {
       this.changePaintOpacity(valid);
       this.drawContents(info, rect, valid);
       this.changePaintOpacity(true);
   }
};

var oldSaveFileDrawContents = Window_SavefileList.prototype.drawContents;
Window_SavefileList.prototype.drawContents = function(info, rect, valid) {
   
   var bottom = rect.y + rect.height;
   if (rect.width >= 420) {
//項目0(タイトル表示)------------------------------------------------------------------------
           //this.drawText(info.title, rect.x + 142, rect.y, item0Length);
           this.originalDrawText(info.title, rect.x + 142, rect.y, item0Length);


//-----------------------------------------------------------------------------
       if (valid) {
           this.drawPartyCharacters(info, rect.x + 125, bottom - 28);//-6 -12 -20            
//レベル表示-------------------------------------------------------------------
       if (levelOnOff == 1) {
           this.contents.fontSize = 16;
           //this.drawText(TextManager.levelA + " " + info.level1, rect.x + 5, rect.y + levelPosY, 40);//72 23
           this.originalDrawText(TextManager.levelA + " " + info.level1, rect.x + 5, rect.y + levelPosY, 40);//72 23
           if (info.characters.length == 2) {
               //this.drawText(TextManager.levelA + " " + info.level2, rect.x + 5 + 48, rect.y + levelPosY, 40);}
               this.originalDrawText(TextManager.levelA + " " + info.level2, rect.x + 5 + 48, rect.y + levelPosY, 40);}
           this.contents.fontSize = 20;
       }
//-----------------------------------------------------------------------------
       }
   }
   var lineHeight = this.lineHeight();
   var y2 = bottom - lineHeight;
   if (y2 >= lineHeight) {
//項目1 右上（プレイ時間表示）-------------------------------------------------------------------
       //this.drawText(BBSWItem1T, rect.x + 525, y2 - 57, BBSWTF1 - 10);
       //this.drawText(info.playtime, rect.x + 525 + BBSWTF1, y2 - 57, 266 - BBSWTF1, 'right');
       this.originalDrawText(item_1_title, rect.x + 585, y2 - 57, titleFrameLength_1 - 10);
       this.originalDrawText(info.playtime, rect.x + 585 + titleFrameLength_1, y2 - 57, 266 - titleFrameLength_1 + 30, 'right');

//-----------------------------------------------------------------------------
//項目2 右下（マップ名表示）-------------------------------------------------------------------
       //this.drawText(item2Title, rect.x + 525, y2 - 7, BBSWTF2 - 10);
       //this.drawText(info.mapname, rect.x + 525 + BBSWTF2, y2 - 7, 266 - BBSWTF2, 'right');
       this.originalDrawText(item2Title, rect.x + 585, y2 - 7, titleFrameLength_2 - 10);
       this.originalDrawText(info.mapname, rect.x + 585 + titleFrameLength_2, y2 - 7, 266 - titleFrameLength_2 + 30, 'right');
//-----------------------------------------------------------------------------
//項目3 左上（所持金表示）-------------------------------------------------------------------
       //this.drawText(BBSWItem3T, rect.x + 215, y2 - 57, BBSWTF3 - 10);
       //this.drawText(info.gold + TextManager.currencyUnit, rect.x + 215 + BBSWTF3, y2 - 57, 266 - BBSWTF3, 'right');
       this.originalDrawText(item_3_title, rect.x + 245, y2 - 57, titleFrameLength_3 - 10);
       this.originalDrawText(info.gold + TextManager.currencyUnit, rect.x + 245 + titleFrameLength_3, y2 - 57, 266 - titleFrameLength_3 + 30, 'right');

       //-----------------------------------------------------------------------------
//項目4 左下（時刻表示）-------------------------------------------------------------------
       //this.drawText(BBSWItem4T, rect.x + 215, y2 - 7, BBSWTF4 - 10);
       this.originalDrawText(item_4_title, rect.x + 245, y2 - 7, titleFrameLength_4 - 10);
       if(info.value1 != 0){
           //this.drawText(info.value1 + " Day(s)　" + ("0"+info.value2).slice(-2) + " Hour(s)" + ("0"+info.value3).slice(-2) + " Minute(s)", rect.x + 215 + BBSWTF4, y2 - 7, 266 - BBSWTF4, 'right');
           this.originalDrawText(" Day　" + info.value1 + "     " + ("0" + info.value2).slice(-2) + ":" + ("0" + info.value3).slice(-2) + "", rect.x + 245 + titleFrameLength_4 + 30, y2 - 7, 266 - titleFrameLength_4, 'right');
       }
       else
       {
           //this.drawText(" 　　　" + ("0"+info.value2).slice(-2) + " Hour(s)" + ("0"+info.value3).slice(-2) + " Minute(s)", rect.x + 215 + BBSWTF4, y2 - 7, 266 - BBSWTF4, 'right');  
           this.originalDrawText(" 　　　" + ("0"+info.value2).slice(-2) + ":" + ("0" + info.value3).slice(-2) + "", rect.x + 245 + titleFrameLength_4, y2 - 7, 266 - titleFrameLength_4 + 30, 'right');      	
       }
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
   }
};

var _Window_SavefileList_prototype_drawFileId = Window_SavefileList.prototype.drawFileId;
Window_SavefileList.prototype.drawFileId = function(id, x, y) {
   //this.drawText(TextManager.file + ' ' + id, x, y, 120);
   this.originalDrawText(TextManager.file + ' ' + id, x, y, 120);
};

})();