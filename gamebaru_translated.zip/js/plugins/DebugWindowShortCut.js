/*---------------------------------------------------------------------------*
 * 2018/07/04 kido0617
 * http://kido0617.github.io/
 * 完全に自由にどうぞ。
 * クレジットの表記もいりません。
 * Ver.1.0
 *---------------------------------------------------------------------------*/

/*:
 * @plugindesc デバッグウィンドウにショートカットキーを追加するプラグイン
 * @author kido0617
 * @help
 * 以下を参照
 * http://kido0617.github.io/rpgmaker/2018-07-04-debug-shortcut/
 * 
*/



(function(){

  Input.keyMapper[66] = 'B';
  Input.keyMapper[86] = 'V';
  Input.keyMapper[8] = 'BackSpace';
  for(var i = 0; i <= 9; i++){
    Input.keyMapper[48 + i] = String(i);
  }
  Scene_Debug.prototype.update = function() {
    Scene_Base.prototype.update.call(this);
    if(Input.isTriggered('B')){
      this.shortCutType = 'B';
      this.strNum = "";
      this.jump();
    }else if(Input.isTriggered('V')){
      this.shortCutType = 'V';
      this.strNum = "";
      this.jump();
    }else if(Input.isTriggered('BackSpace')){
      if(this.strNum && this.strNum.length > 0) this.strNum = this.strNum.substr(0, this.strNum.length - 1);
      this.jump();
    }
    for(var i = 0; i <= 9; i++){
      if(Input.isTriggered(String(i))){
        if(this.strNum == "" && i == 0) return;  "いきなり0は無し"
        this.strNum += String(i); 
        this.jump();
      }
    }
  };

  Scene_Debug.prototype.jump = function(){
    if(!this.shortCutType) return;
    var rangeIndex = this.shortCutType == 'B' ? 0 : this._rangeWindow._maxSwitches;
    if(this.strNum != ''){
      var num = parseInt(this.strNum);
      if((this.shortCutType =='B' && num > $dataSystem.switches.length) ||
       (this.shortCutType =='V' && num > $dataSystem.variables.length)){
         SoundManager.playBuzzer();
         //最大超えたら最大値にしておく
         num = this.shortCutType == 'B' ?  $dataSystem.switches.length - 1 : $dataSystem.variables.length - 1;
      }
      rangeIndex += Math.floor((num - 1) / 10);
      this._rangeWindow.select(rangeIndex);
      this._rangeWindow.deactivate();
      this._editWindow.activate();
      this._editWindow.select((num -1) % 10);
    }else{
      this._rangeWindow.select(rangeIndex);
      this._rangeWindow.activate();
      this._editWindow.deactivate();
    }
    this.refreshHelpWindow();
  }

  var refreshHelpWindow = Scene_Debug.prototype.refreshHelpWindow;
  Scene_Debug.prototype.refreshHelpWindow = function() {
    refreshHelpWindow.call(this);
    var str = this.shortCutType + this.strNum;
    this._debugHelpWindow.drawTextEx(str, 450, this._debugHelpWindow.lineHeight() * 4);
  };
})();