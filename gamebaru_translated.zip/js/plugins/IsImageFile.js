// isImageFile.js
/*:
 * @plugindesc isImageFile
 * @author suzu
 *
 * @help 連番画像ファイルの最大値チェックができます。
 *
 * 使い方はコードが書ける場所で
 * $gameSystem.isImageFile(ファイル名{i},<offset>).then(function(n){
 *  // 処理
 *  // nには連番の最大値が入っています
 *  // offsetは省略可
 * });
 *
 * 例)
 * ファイル名が<CloudySky1>~<CloudySky9>だった場合は
 * "CloudySky{i}"という引数を与えます。
 *
 * {ii}のようにiをn個重ねるとn桁のゼロ埋めになります。
 */

(function(){
  Game_System.prototype.isImageFile = function(filename,o,l){
    return new Promise(function(resolve,reject){
      var img = [];
      var src = "img/pictures/" + filename + ".png";
      var loadCount = 0, loadSuccess = 0;
      var m = src.match(/{i+}/);
      var limit = l || getLimit(filename,m), offset = o || 1;

      for(var i=offset;i<limit;i++){
        img[i] = new wrap();
        img[i].img.onload = function(){
          loadCheck(true);
        }
        img[i].timer = setTimeout(function(){
          loadCheck(false);
        }, 100);

        img[i].img.src = getFilename(src,i,m);
      }

      function loadCheck(done){
        loadCount += 1;
        if(done) loadSuccess += 1;

        if(loadCount >= (limit-offset)){
          resolve(loadSuccess);
        }
      }

      function getFilename(f,n,m){
        if(!m) return f;

        var len = m[0].length - 2;

        return f.replace(m,("000000000"+n).slice(-1 * len));
      }

      function getLimit(f,m){
        if(!m) return 10;

        var len = (m[0].length - 2);
        var lim = "";
        for(var i=0;i<len;i++){
          lim += "9";
        }
        return parseInt(lim);
      }

      function wrap(){
        return {
          img:new Image(),
          timer:null,
        }
      }
    });
  }
})();
