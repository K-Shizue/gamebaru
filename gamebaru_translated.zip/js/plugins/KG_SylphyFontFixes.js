(function()
{
    SetOriginalBaseDrawTextFuncs();

    function SetOriginalBaseDrawTextFuncs()
    {
        var originalBaseDrawText = KG.OriginalFuncs.Window_Base.drawText;

        Window_Selectable.prototype.drawText = 

        Window_BattleActor.prototype.drawText =
        Window_BattleEnemy.prototype.drawText =
        Window_BattleItem.prototype.drawText = 
        Window_BattleLog.prototype.drawText = 
        Window_BattleSkill.prototype.drawText =
        Window_BattleStatus.prototype.drawText =

        Window_ShopBuy.prototype.drawText =
        Window_ShopCommand.prototype.drawText =
        Window_ShopNumber.prototype.drawText =
        Window_ShopSell.prototype.drawText =
        Window_ShopStatus.prototype.drawText =
        
        Window_Status.prototype.drawText =

        Window_EquipItem.prototype.drawText =
        Window_EquipSlot.prototype.drawText =
        Window_EquipStatus.prototype.drawText =

        Window_Gold.prototype.drawText =

        Window_MenuActor.prototype.drawText =
        Window_MenuStatus.prototype.drawText =

        Window_SkillList.prototype.drawText =
        Window_SkillStatus.prototype.drawText =

        Window_MapName.prototype.drawText = 

        Window_Help.prototype.drawText =
        Window_PartyCommand.prototype.drawText =
        
        Window_EnemyVisualSelect.prototype.drawText =
        Window_SoloStatus.prototype.drawText =
        Window_SoloItemStatus.prototype.drawText =

        Window_MagicSlot.prototype.drawText =
        Window_MagicItem.prototype.drawText =
        Window_MagicCommand.prototype.drawText =
        Window_MagicStatus.prototype.drawText =

        originalBaseDrawText;
    }



    var originalCommandDrawText = KG.OriginalFuncs.Window_Command.drawText;
    //Window_Command.prototype.drawText = originalCommandDrawText;
   
})();

/*:
* @plugindesc: Applies various edits to fix font issues so there's less need to edit other various individual scripts.
* @author: AzureArtism
* @help Needs the KG_OriginalFuncs plugin to work. Please make sure that this 
* plugin is at the bottom in the Plugin Manager.
*/

