/*:
* @plugindesc Keeps archived versions of some original API funcs to help fix funkiness
* @author AzureArtism
* @help Please make sure that this is at the top of the Plugin Manager.
*/

(function()
{
    var KG = KG || {};
    KG.OriginalFuncs = 
    {
        Window_Base:
        {
            drawText: Window_Base.prototype.drawText,
            drawTextEx: Window_Base.prototype.drawTextEx,

            drawActorName: Window_Base.prototype.drawActorName,
            drawActorNickname: Window_Base.prototype.drawActorNickname,

            drawActorHp: Window_Base.prototype.drawActorHp,
            drawActorMp: Window_Base.prototype.drawActorMp,
            drawActorTp: Window_Base.prototype.drawActorTp,
        },

        Window_Command:
        {
            drawText: Window_Command.prototype.drawText,
            drawTextEx: Window_Command.prototype.drawTextEx
        }
    };

    window.KG = KG;
})();