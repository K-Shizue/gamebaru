
//=============================================================================
// BalloonLoopWithoutSkip.js
// ----------------------------------------------------------------------------
// Copyright (c) 2018 Suzu
// This software is released under the MIT License.
// ----------------------------------------------------------------------------
// Version
// 1.0.0 2018/09/19 初版
//=============================================================================

/*:ja
 * @plugindesc 吹き出しをループ表示中スキップ無効プラグイン
 * @author すず
 *
 * @help
 *
 * tomoakyさんのプラグイン(TMBalloonLoop.js)がONの場合に
 * 桐原巳弥人(KIRIHARA Miyahito)さんのプラグイン(BalloonSkip.js)を無効にします。
 *
 * 使い方：
 *
 *    BalloonSkipを削除もしくはOFFにして本プラグインを追加します。
 *    このプラグインにはプラグインコマンドはありません。
 *
 *    以下、BalloonSkip.js引用です。
 *    " フキダシアイコンを表示している間、okキーあるいはctrlキーが押されたら
 *    （押されていたら）それを終了します。
 *    okキーが既に押しっぱなしだった場合は、フキダシアイコンが一瞬だけ見えます。"
 *
 * 利用規約：
 *    作者に無断で改変、再配布が可能で、利用形態（商用、18禁利用等）
 *    についても制限はありません。
 *
*/

(function(){
  'use strict';
  Sprite_Character.prototype.startBalloon = function(){
    if (!this._balloonSprite){
      var balloonLoop = (typeof this._character.balloonLoop == "function")
        ? this._character.balloonLoop() : false;
      this._balloonSprite = (!balloonLoop)
        ? new Sprite_BalloonEnableSkip() : new Sprite_Balloon();
    }
    this._balloonSprite.setup(this._character.balloonId());
    this.parent.addChild(this._balloonSprite);
  };

  function Sprite_BalloonEnableSkip(){
    this.initialize.apply(this, arguments);
  }

  Sprite_BalloonEnableSkip.prototype = Object.create(Sprite_Balloon.prototype);
  Sprite_BalloonEnableSkip.prototype.constructor = Sprite_BalloonEnableSkip;

  Sprite_BalloonEnableSkip.prototype.initialize = function(){
    Sprite_Balloon.prototype.initialize.call(this);
  }

  var _Sprite_Balloon_update = Sprite_Balloon.prototype.update;
  Sprite_BalloonEnableSkip.prototype.update = function(){
    if(Input.isTriggered("ok") || Input.isPressed("control")){
      this._duration = 0;
    }
    //if(Input.isPressed("ok")){
    //  this._duration -= 5;
    //}
    _Sprite_Balloon_update.apply(this);
  }
})();
