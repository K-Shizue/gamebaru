
//=============================================================================
// SZBattleSkillVisibility.js
// ----------------------------------------------------------------------------
// Copyright (c) 2018 Suzu
// ----------------------------------------------------------------------------
// Version
// 1.0.0 2018/09/10 初版
//=============================================================================

/*:ja
 * @plugindesc 戦闘中スキル非表示設定プラグイン
 * @author すず
 *
 * @help
 *
 * 予め指定した条件により、戦闘中に表示させるスキルを制限できます。
 *
 * 使い方：
 *
 *    スキルのメモ欄にタグを書き込んで使用します。
 *    <SZBSV:[BOOLEAN]>
 *
 *    [BOOLEAN]
 *      trueかfalseを記述します。
 *      falseの場合に非表示、trueの場合と何も書かれていない場合は表示されます。
 *
 *
 *
*/

(function(){

  'use strict';

  var _Window_BattleSkill_includes = Window_BattleSkill.prototype.includes;
  Window_BattleSkill.prototype.includes = function(item){
    return this._actor && this._actor.canUse(item) && this.isSkillVisible(item);
  }

  Window_BattleSkill.prototype.isSkillVisible = function(item){
    var parameter = item.meta["SZBSV"];
    var visibility = (parameter == null) ? true : !(parameter);
    return visibility;
  }
})();
