//=============================================================================
// NoSellIteme.js
//=============================================================================

/*:ja
 * @plugindesc アイテムの売値を0(売却禁止)にするプラグインです。
 */

 Window_ShopSell.prototype.isEnabled = function(item) {
	if(item != undefined){
		if(item.meta.noSell){
			return false;
		} 
    	return item && item.price > 0; 
	}
}; 