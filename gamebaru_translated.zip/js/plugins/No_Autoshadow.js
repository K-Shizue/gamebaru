//=============================================================================
// No Auto Shadows
// Version: 1.0
//=============================================================================
 /*:
 * @plugindesc Removes automatic shadows from displaying in game.
 * @author Archeia
 * 
 * @help
 * 
 * @param prefix
 * @desc Write <No_shadow> on the map note to disable shadows. 
 * @default No_shadow
 */
 /*:ja
 * @plugindesc ゲーム内で自動生成される影を非表示にします。
 * @author Archeia
 * 
 * @help
 * 
 * @param prefix
 * @desc マップのメモ欄に<No_shadow>のように記載すると影が無効になります。
 * @default No_shadow
 * 
 */
 //=============================================================================
 //==============================================================================================
 // ** Tilemap
 //==============================================================================================
 //==============================================================================================
 // * Draw Shadows
 //==============================================================================================


(function(){
    'use strict';
    var prefix = PluginManager.parameters('No_Autoshadow').prefix;

    var _Tilemap_drawShadow = Tilemap.prototype._drawShadow;
    Tilemap.prototype._drawShadow = function(bitmap, shadowBits, dx, dy) {
        // none script;
    };

    var _ShaderTilemap_drawShadow = ShaderTilemap.prototype._drawShadow;
    if (ShaderTilemap) {
        ShaderTilemap.prototype._drawShadow = function(layer, shadowBits, dx, dy) {
            // none script
        };
    }

    Spriteset_Map.prototype.createTilemap = function() {
        if (Graphics.isWebGL()) {
            this._tilemap = new ShaderTilemap();
        } else {
            this._tilemap = new Tilemap();
        }
        
        var drawshadow = !$dataMap.meta[prefix];
        if(drawshadow){
            this._tilemap._drawShadow = Graphics.isWebGL() ? _ShaderTilemap_drawShadow : _Tilemap_drawShadow;
        }
        this._tilemap.tileWidth = $gameMap.tileWidth();
        this._tilemap.tileHeight = $gameMap.tileHeight();
        this._tilemap.setData($gameMap.width(), $gameMap.height(), $gameMap.data());
        this._tilemap.horizontalWrap = $gameMap.isLoopHorizontal();
        this._tilemap.verticalWrap = $gameMap.isLoopVertical();
        this.loadTileset();
        this._baseSprite.addChild(this._tilemap);
    };
})();

