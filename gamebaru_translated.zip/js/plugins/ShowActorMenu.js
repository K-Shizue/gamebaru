//--------------------------------------------------
// ShowActorMenu.js
//--------------------------------------------------

/*:
 * @plugindesc プレースホルダー
 * @author すず
 * @help
 * プラグインコマンド
 * SHOW_ACTOR_MENU or メニュー画像表示
*/

(function(){
  'use strict';

  var getCommand = function(c){
    return (c || "").toUpperCase();
  };

  //--------------------------------------------------
  // Game_Interpreter
  //--------------------------------------------------

  Game_Interpreter.prototype.pluginCommandShowActorMenu = function(){
	switch($gameActors._data[1]._equips[1]._itemId){
		case 113: //馬鹿には見えない服
			if ($gameSwitches.value(8)==false){
				var name = "[1-01-naked]face_"
			}
			else{
				var name = "[1-01-naked(Choker)]face_"
			}
			break;
		case 114: //盗賊の服
			var name = "[1-02-default(scarf)]face_"
			break;
		case 115: //破損した盗賊の服
			var name = "[1-03-default(ripped)]face_"
			break;
		case 116: //宿屋のランジェリー
			var name = "[1-04-Inn]face_"
			break;
		case 117: //盗賊の服（首輪付き）
			var name = "[1-05-default(Choker)]face_"
			break;
		case 118: //下着
			var name = "[1-06-underwear]face_"
			break;
		case 119: //訓練衣装
			var name = "[1-07-training]face_"
			break;
		case 120: //改造訓練衣装
			var name = "[1-08-training(remodel)]face_"
			break;
		case 121: //エロスの衣
			var name = "[1-09-eros]face_"
			break;
		case 122: //真・エロスの衣
			var name = "[1-10-eros(true)]face_"
			break;
		case 123: //マイクロビキニ
			var name = "[1-11Micro_bikini]face_"
			break;
		case 124: //ディアンドル
			var name = "[1-12-dirndl]face_"
			break;
		case 125: //丸出しディアンドル
			var name = "[1-13-dirndl(opened)]face_"
			break;
		case 126: //アレンジディアンドル
			var name = "[1-14-dirndl(arranged)]face_"
			break;
		case 127: //オークの服
			var name = "[1-15-ork]face_"
			break;
		case 128: //C級バニースーツ
			var name = "[1-16-bunny(C)]face_"
			break;
		case 129: //壊れたバニースーツ
			var name = "[1-17-bunny(broken)]face_"
			break;
		case 130: //B級バニースーツ
			var name = "[1-18-bunny(B)]face_"
			break;
		case 131: //A級バニースーツ
			var name = "[1-19-bunny(A)]face_"
			break;
		case 132: //S級バニースーツ
			var name = "[1-20-bunny(S)]face_"
			break;
		case 133: //サキュバスの夢
			var name = "[1-21-Succubus]face_"
			break;
		case 134: //マイクロビキニアーマー
			var name = "[1-22-MBArmor]face_"
			break;
		case 135: //解体屋の作業着
			var name = "[1-23-Break]face_"
			break;
		case 136: //壊れた解体屋の作業着
			var name = "[1-24-Break2]face_"
			break;
		case 137: //布教者の衣
			var name = "[1-26-Sister]face_"
			break;
		case 138: //ライラー信者のローブ
			var name = "[1-25-Robe]face_"
			break;
		case 139: //ナース服
			var name = "[1-28-Nurse]face_"
			break;
		case 171: //ボディペイント
			var name = "[1-29-Bodypaint]face_"
			break;
		case 172: //挑戦者の服
			var name = "[1-30-Challenger]face_"
			break;
		case 173: //破れた挑戦者の服
			var name = "[1-31-Challenger(Break)]face_"
			break;
		case 174: //娼婦の服
			var name = "[1-32-Prostitute]face_"
			break;
		case 175: //守衛の鎧
			var name = "[1-27-Armor]face_"
			break;
		case 176: //体操服ブルマ
			var name = "[1-34-Bloomers]face_"
			break;
		case 177: //穴あきブルマ
			var name = "[1-35-Bloomers(ripped)]face_"
			break;
		case 178: //牛柄ビキニ
			var name = "[1-36-farm]face_"
			break;
		default:
			console.log("該当するものがありません。");
			break;
		}
	if($gameVariables.value(179)<10){
		name +="0"+ $gameVariables.value(179);
	}
	else{
		name += $gameVariables.value(179);
	}
    $gameScreen.showPicture(45, name, 0, $gameVariables.value(107), $gameVariables.value(108), 100, 100, 255, 0);
};

  var _Game_Interpreter_pluginCommand      = Game_Interpreter.prototype.pluginCommand;
  Game_Interpreter.prototype.pluginCommand = function(command, args){
    _Game_Interpreter_pluginCommand.apply(this, arguments);

    var commandName = getCommand(command);

    switch (commandName) {
      case "SHOW_ACTOR_MENU":
      case "メニュー画像表示":
        this.pluginCommandShowActorMenu();
        break;
    }
  };
})();
