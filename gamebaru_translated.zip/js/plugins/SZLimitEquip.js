
//=============================================================================
// SZLimitEquip.js
// ----------------------------------------------------------------------------
// Copyright (c) 2018 Suzu
// This software is released under the MIT License.
// http://opensource.org/licenses/mit-license.php
// ----------------------------------------------------------------------------
// Version
// 1.0.1 2018/09/30 全体無効スイッチを追加
// 1.0.0 2018/09/22 初版
//=============================================================================

/*:ja
 * @plugindesc 装備制限アイテム作成プラグイン
 * @author すず
 *
 * @param DisableSwitch
 * @desc 装備制限を無効にするスイッチの番号
 * @default 0
 *
 * @help
 *
 * 装備可能になる条件を指定できるようになります。
 *
 * 使い方：
 *
 *    アイテムのメモ欄にタグを書き込んで使用します。
 *    <SZLEQ:[CONDITION]>
 *
 *    [CONDITION] 必須
 *      装備可能になる条件を指定します。
 *      V[n],S[n] でゲーム変数、ゲームスイッチを条件に含むことができます。
 *      また、javascriptで使用可能な各関数等も使用できます。
 *      ※不等号 > (大なり)は閉じタグとして認識されてしまうので
 *      　もし条件に含める場合は注意してください。
 *
 *      (例) アクターのレベルが30以上で装備可能
 *        <SZLEQ:30 <= this.level>
 *
 *      (例) ゲームスイッチ1がONの場合に装備可能
 *        <SZLEQ:S[1]>
 *
 *
 * プラグインパラメータ：
 *
 *    DisableSwitch
 *      番号でスイッチを指定し、そのスイッチがONの時にプラグインを無効化します。
 *      ※0を指定すると常時有効
 *      ※ただし、スイッチをON->OFFに切り替えた際に、
 *      　自動で装備が変更されないことに注意してください。
 *
 *
*/

(function(){
  "use strict";

  var parameters = PluginManager.parameters("SZLimitEquip");
  var disableSw = Number(parameters["DisableSwitch"]);

  Game_BattlerBase.prototype.isLimitEquip = function(){
    return (disableSw > 0) ? (!$gameSwitches.value(disableSw)) : true;
  }

  Game_BattlerBase.prototype.escapeLimitEquipParameter = function(text){
    text = text.replace(/V\[(\d+)\]/gi, function() {
      return "$gameVariables.value(" + (parseInt(arguments[1])) + ")";
    }.bind(this));
    text = text.replace(/S\[(\d+)\]/gi, function() {
      return "$gameSwitches.value(" + (parseInt(arguments[1])) + ")";
    }.bind(this));

    return text;
  }

  var _Game_BattlerBase_canEquip = Game_BattlerBase.prototype.canEquip;
  Game_BattlerBase.prototype.canEquipLegacy = function(item){
    return _Game_BattlerBase_canEquip.call(this, item);
  }

  Game_BattlerBase.prototype.canEquip = function(item){
    if(this.canEquipLegacy(item)){
      var meta = item.meta["SZLEQ"];
      if(this.isLimitEquip() && meta != null){
        var param = this.escapeLimitEquipParameter(meta);
        return (new Function( "return !!("+ param + ");" ))();
      }
      else{
        return true;
      }
    }
    else{
      return false;
    }
  }

  Window_EquipItem.prototype.makeItemList = function(){
    this._data = $gameParty.allItems().filter(function(item){
      return this.isNeedsDraw(item);
    }, this);
    if(this.isNeedsDraw(null)){
      this._data.push(null);
    }
  }

  Window_EquipItem.prototype.isNeedsDraw = function(item){
    if(item === null){
      return true;
    }
    if(this._slotId < 0 || item.etypeId !== this._actor.equipSlots()[this._slotId]){
      return false;
    }
    return this._actor.canEquipLegacy(item);
  }

  var _Window_EquipItem_isEnabled = Window_EquipItem.prototype.isEnabled;
  Window_EquipItem.prototype.isEnabled = function(item){
    return this._actor.canEquip(item);
  }

  var _Window_EquipItem_isCurrentItemEnabled = Window_EquipItem.prototype.isCurrentItemEnabled;
  Window_EquipItem.prototype.isCurrentItemEnabled = function(){
    var item = this.item();
    return !item ? true : this._actor.canEquip(item);
  }
})();
