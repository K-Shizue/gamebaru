/*:
    Most of them, anyway. The rest should be handled by
    edits to other plugins, or other separate ones made
    specifically to solve these problems.
*/

(function()
{
    
    var origDrawText = Window_Base.prototype.drawText;
    var origCommandDrawText = Window_Command.prototype.drawText;

    // Extending the drawTextEx func so we don't have to manually tinker with
    // the menus' text placements as much
    /**
     * 
     * @param {string} text 
     * @param {number} x 
     * @param {number} y 
     * @param {Rectangle} rect The window's rect by default
     * @param {string} align Left by default
     */
    Window_Base.prototype.drawTextEx = function(text, x, y, rect, align) 
    {
        if (text) 
        {
            text += ""; 
            // ^In case what was passed was a number or such. Hooray for string coercion!

            if (align != null)
            {
                rect = rect || this.contents.rect;
                x = this.XForTextAlign(rect, text, align);
            }

            var textState = { index: 0, x: x, y: y, left: x };

            textState.text = this.convertEscapeCharacters(text);
            textState.height = this.calcTextHeight(textState, false);

            while (textState.index < textState.text.length) 
            {
                this.processCharacter(textState);
            }
            return textState.x - x;
        } 
        else 
        {
            return 0;
        }
    };


    /**
     * Returns an x position to align the text, based on the rect passed and
     * the align arg.
     * @param {Rectangle} rect
     * @param {string} text
     * @param {string} align 
     */
    Window_Base.prototype.XForTextAlign = function(rect, text, align)
    {
        var xVal = rect.x; // For the default left-align
        var textWidth = this.contents.measureTextWidth(text);
        var offsetToTheRight = 0;
        var offsetToTheLeft = 0;

        if (align == 'center')
        {
            var halfRectWidth = Math.floor(rect.width / 2);
            offsetToTheRight = halfRectWidth;

            var halfTextWidth = Math.floor(textWidth / 2);
            offsetToTheLeft = halfTextWidth;
        }
        else if (align == 'right')
        {
            offsetToTheRight = rect.width;
            offsetToTheLeft = textWidth;
        }

        xVal += offsetToTheRight - offsetToTheLeft;

        return xVal;
    }

    // Applies a blanket spacing fix. Much of everything after this fixes other
    // placement issues on a case-by-case basis.
    Window_Base.prototype.drawText = 
    function(text, x, y, maxWidth, align)
    {
        this.drawTextEx(text, x, y, null, align);
    };
    
    // Just to make it look nicer.
    Window_TitleCommand.prototype.drawText =
    Window_GameEnd.prototype.drawText =
    Window_Gold.prototype.drawText =
    //Window_ShopNumber.prototype.drawText =
    function(text, x, y, maxWidth, align)
    {
        this.drawTextEx(text, x, y, null, 'center');
    };

    Window_ShopNumber.prototype.initialize = function(x, y, height) 
    {
        var width = this.windowWidth();
        Window_Selectable.prototype.initialize.call(this, x, y, width, height);
        this._item = null;
        this._max = 1;
        this._price = 0;
        this._number = 1;
        this._currencyUnit = TextManager.currencyUnit;
        this.createButtons();

        // Set up number rect
        var thisRect = this.contents.rect;
        var widthOffset = 15;
        this.numberRect = new Rectangle(thisRect.x, thisRect.y, 
            thisRect.width - widthOffset, thisRect.height);
    };

    Window_ShopNumber.prototype.drawNumber = function() 
    {
        var x = this.cursorX();
        var y = this.itemY();
        var width = this.cursorWidth() - this.textPadding();
        this.resetTextColor();
        this.drawTextEx(this._number, x, y, this.numberRect, 'right');
    };

    // So the price isn't hidden by the gold icon
    Window_ShopNumber.prototype.drawTotalPrice = function() {
        var total = this._price * this._number;
        var width = this.contentsWidth() - this.textPadding();
        var shiftedXPos = -50;
        this.drawCurrencyValue(total, this._currencyUnit, shiftedXPos, this.priceY(), width);
    };

    // 
    //var theRightBarEdge = 290;

    //Window_MenuCommand.prototype.drawActorHp = 
    Window_MenuStatus.prototype.drawActorHp =
    Window_Status.prototype.drawActorHp =
    function(actor, x, y, width)
    {
        width = width || (186 * 2);
        var color1 = this.hpGaugeColor1();
        var color2 = this.hpGaugeColor2();
        this.drawGauge(x, y, width, actor.hpRate(), color1, color2);
        this.changeTextColor(this.systemColor());
        this.drawText(TextManager.hpA, x, y, 44);

        this.drawCurrentAndMax(actor.hp, actor.mhp, x, y, width,
                            this.hpColor(actor), this.normalColor());
    };

    var widthIncrease = 50;

    //Window_MenuCommand.prototype.drawActorMp = 
    Window_MenuStatus.prototype.drawActorMp =
    Window_Status.prototype.drawActorMp =
    function(actor, x, y, width)
    {
        width = width || (186 * 2);
        var color1 = this.mpGaugeColor1();
        var color2 = this.mpGaugeColor2();
        this.drawGauge(x, y, width, actor.hpRate(), color1, color2);
        this.changeTextColor(this.systemColor());
        this.drawText(TextManager.mpA, x, y, 44);

        this.drawCurrentAndMax(actor.mp, actor.mmp, x, y, width,
                            this.mpColor(actor), this.normalColor());
    };

    //Window_MenuCommand.prototype.drawCurrentAndMax = 
    Window_MenuStatus.prototype.drawCurrentAndMax =
    Window_Status.prototype.drawCurrentAndMax =
    function(current, max, x, y,
        width, color1, color2)
    {
        // Have the current and max be one string, without worrying about any text-color
        // stuff. And place them so they're roughly at the right edge
        // of the gauge they're to be drawn over.
        var toDraw = current + "/" + max;
        var textWidth = this.contents.measureTextWidth(toDraw);
        this.resetTextColor();
        this.drawTextEx(toDraw, width - textWidth, y);
    };

    var oldSkillStatusInitialize = Window_SkillStatus.prototype.initialize;
    Window_SkillStatus.prototype.initialize = function(x, y, width, height) {
        oldSkillStatusInitialize.call(this, x, y, width, height);
        var thisRect = this.contents.rect;
        this.hpMpBarRect = new Rectangle(thisRect.x - 30, thisRect.y, 
            thisRect.width, thisRect.height);
    };

    var skillStatusWidthOffset = -50;
    
    Window_SkillStatus.prototype.drawCurrentAndMax =
    function(current, max, x, y,
        width, color1, color2)
    {
        // Have the current and max be one string, without worrying about any text-color
        // stuff. And place them so they're roughly at the right edge
        // of the gauge they're to be drawn over.
        var toDraw = current + "/" + max;
        var textWidth = this.contents.measureTextWidth(toDraw);
        this.resetTextColor();

        this.drawTextEx(toDraw, width - textWidth, y, this.hpMpBarRect, 'right');
    };

    // Just a drawText -> draw
    Window_ItemList.prototype.drawItemName = function(item, x, y, width) 
    {
        width = width || 312;
        if (item) {
            var iconBoxWidth = Window_Base._iconWidth + 4;
            this.resetTextColor();
            this.drawIcon(item.iconIndex, x + 2, y + 2);
            //this.drawTextEx(item.name, x + iconBoxWidth, y);
            this.drawText(item.name, x + iconBoxWidth, y);
        }
    };

    // Due to how each row of items has the same rect, the extended drawTextEx doesn't 
    // work well enough... We have to hard-code an offset here.
    var itemNumberOffset = 425;

    Window_ItemList.prototype.drawItemNumber = function(item, x, y, width) 
    {
        if (this.needsNumber()) 
        {
            //this.drawText(':', x, y, width - this.textWidth('00'), 'right');
            //this.drawText($gameParty.numItems(item), x, y, width, 'right');
            this.drawTextEx("x" + $gameParty.numItems(item), x + itemNumberOffset, y);
        }
    };

    Window_ItemCategory.prototype.drawItem = 
    Window_ShopCommand.prototype.drawItem =
    function(index) 
    {
        var rect = this.itemRectForText(index);
        var align = this.itemTextAlign();
        this.resetTextColor();
        this.changePaintOpacity(this.isCommandEnabled(index));
        //this.drawText(this.commandName(index), rect.x, rect.y, rect.width, align);

        // Need to pass a rect for each item category, so things are aligned right
        this.drawTextEx(this.commandName(index), rect.x, rect.y, rect, align);
    };

    Window_Status.prototype.drawBasicInfo = function(x, y) 
    {
        var lineHeight = this.lineHeight();
        this.drawActorLevel(this._actor, x, y + lineHeight * 0);
        this.drawActorIcons(this._actor, x, y + lineHeight * 1);
        this.drawActorHp(this._actor, x, y + lineHeight * 2);
        this.drawActorMp(this._actor, x, y + lineHeight * 3);
    };

    Window_Status.prototype.drawActorLevel = 
    Window_SkillStatus.prototype.drawActorLevel =
    function(actor, x, y) 
    {
        // Much like with the drawCurrentAndMax, just combine all the pieces of
        // the string without worrying about coloring them differently.
        this.changeTextColor(this.systemColor());
        this.drawText(TextManager.levelA + " " + actor.level, x, y, 48);
        this.resetTextColor();
    };
    
    Window_Status.prototype.drawParameters = function(x, y) 
    {
        var lineHeight = this.lineHeight();

        // The default rect is the width of the screen, which messed up the alignment. 
        // We need to make a smaller one so things are placed right.
        var rect = new Rectangle(this.contents.rect.x, this.contents.rect.y,
            this.contents.rect.width * 0.4, this.contents.rect.height);

        for (var i = 0; i < 6; i++) 
        {
            var paramId = i + 2;
            var y2 = y + lineHeight * i;
            this.changeTextColor(this.systemColor());
            this.drawText(TextManager.param(paramId), x, y2, 160);
            this.resetTextColor();
            
            this.drawTextEx(this._actor.param(paramId), x, y2, rect, 'right');
        }
    };

    // The synthesis menu stuff needs to be edited in its own script;
    // aliasing stuff here doesn't register for some reason

    var oldDrawText = Window_Message.prototype.drawText;
    Window_Message.prototype.drawText = function(text, x, y, maxWidth, align)
    {
        console.log("Window message draw text");
        return oldDrawText.call(this, text, x, y, maxWidth, align);
    };

    
    Window_KeyConfig.prototype.drawItemKey = function(index) 
    {
		this.resetFontSettings();
		this.contents.fontSize -= 8;
		this.resetTextColor();
		this.changePaintOpacity(true);
		var rect = this.itemRectForText(index);
        var align = this.itemTextAlign();
        //origDrawText.call(this, this.visualName(index), rect.x, rect.y, rect.width, align);
        //this.drawText(this.visualName(index), rect.x, rect.y, rect.width, align);
        this.drawTextEx(this.visualName(index), rect.x, rect.y, rect, align);
    };

    Window_KeyConfig.prototype.drawItemAction = function(index) 
    {
        var key = Window_KeyConfig._refId[this.commandName(index)];
        var action = Input.keyMapper[key];
        if (action === undefined) return;
        this.resetFontSettings();
        this.contents.fontSize -= 8;
        var color = this.textColor(Yanfly.Param.KeyConfigActionColor);
        this.changeTextColor(color);
        this.changePaintOpacity(true);
        var rect = this.itemRectForText(index);
        rect.y += this.lineHeight();
        var align = this.itemTextAlign();
        //this.drawText(this.actionKey(action), rect.x, rect.y, rect.width, align);
        this.drawTextEx(this.actionKey(action), rect.x, rect.y, rect, align)
    };

})();