
//=============================================================================
// SZDynamicTraits.js
// ----------------------------------------------------------------------------
// Copyright (c) 2018 Suzu
// ----------------------------------------------------------------------------
// Version
// 1.1.0 2018/10/31 セーブ後追加した特徴が反映されない問題を修正
// 1.0.0 2018/10/12 初版
//=============================================================================

/*:ja
 * @plugindesc 特徴動的操作プラグイン
 * @author すず
 *
 * @help
 *
 * プラグインコマンドを使用して、アクターに特徴を追加します。
 *
 * 使い方：
 *
 *    プラグインコマンドを使用します。
 *    例) 特徴の追加 A1 スキルタイプ追加 1
 *
 *
 * プラグインコマンド：
 *
 *    特徴の追加 (英版: AddTrait):
 *        特徴を追加します。
 *
 *    特徴の削除 (英版: RemoveTrait):
 *        特徴を削除します。
 *
 *
 * プラグインコマンド引数：
 *
 *    引数1： 対象 (Format: [GROUP][ID])
 *        接頭文字[GOURP]がAならアクターを、Cなら職業を変更します。
 *        ※改訂予定、[GROUP]は無視されます。
 *        例) アクターの1番 -> A1
 *
 *    引数2： 項目
 *        特徴の追加欄の項目にあたります。
 *        ※一部未実装
 *        例) 属性有効度
 *        例) スキルタイプ追加
 *
 *    引数3： 種別
 *        特徴の追加欄のタイプ種別にあたる、タイプの通し番号。
 *        例) 項目が属性有効度で物理を選択 -> 1
 *        例) 項目がスキルタイプ追加で必殺技 -> 2
 *
 *    引数4： 値 ※省略可
 *        一部の特徴で使用する、数値パラメータ(実数)です。
 *
*/

(function(){
  "use strict";

  function parseParameter(text){
    if(text.indexOf("A") >= 0){
      return ["actor", parseInt(text.replace("A",""))];
    }
    else if(text.indexOf("C") >= 0){
      return ["class", parseInt(text.replace("C",""))];
    }
    else{
      return ["null", parseInt(text)];
    }
  }

  function methodType(command){
    if(command == "RemoveTrait" || command == "特徴の削除"){
      return 2;
    }
    if(command == "AddTrait" || command == "特徴の追加"){
      return 1;
    }
    return 0;
  }

  function traitType(type){
    var code = 0;
    switch(type){
      case "属性有効度":
      case "ElementRateChange":
        code = Game_BattlerBase.TRAIT_ELEMENT_RATE;
        break;
      case "弱体有効度":
      case "DebufRateChange":
        code = Game_BattlerBase.TRAIT_DEBUFF_RATE;
        break;
      case "ステート有効度":
      case "StateRateChange":
        code = Game_BattlerBase.TRAIT_STATE_RATE;
        break;
      case "ステート無効化":
      case "StateRateChange":
        code = Game_BattlerBase.TRAIT_STATE_RESIST;
        break;
      case "スキルタイプ追加":
      case "SkillTypeAdd":
        code = Game_BattlerBase.TRAIT_STYPE_ADD;
        break;
      case "スキルタイプ封印":
      case "SkillTypeSeal":
        code = Game_BattlerBase.TRAIT_STYPE_SEAL;
        break;
      case "スキル追加":
      case "SkillAdd":
        code = Game_BattlerBase.TRAIT_SKILL_ADD;
        break;
      case "スキル封印":
      case "SkillSeal":
        code = Game_BattlerBase.TRAIT_SKILL_SEAL;
        break;
      case "武器タイプ追加":
      case "WeponTypeAdd":
        code = Game_BattlerBase.TRAIT_EQUIP_WTYPE;
        break;
      case "防具タイプ追加":
      case "ArmorTypeAdd":
        code = Game_BattlerBase.TRAIT_EQUIP_ATYPE;
        break;
      case "装備タイプ固定":
      case "EquipTypeLock":
        code = Game_BattlerBase.TRAIT_EQUIP_LOCK;
        break;
      case "装備タイプ封印":
      case "EquipTypeSeal":
        code = Game_BattlerBase.TRAIT_EQUIP_SEAL;
        break;
    }

    return code;
  }

  var _Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
  Game_Interpreter.prototype.pluginCommand = function(command, args){
    _Game_Interpreter_pluginCommand.call(this, command, args);

    var method = methodType(command);
    if(method > 0){
      var param = parseParameter(args[0]);
      if(!param) return;

      var id = param[1];
      var code = traitType(args[1]);
      var dataId = parseInt(args[2]);
      var value = (args[3] != null) ? parseFloat(args[2]) : 0;

      if(code > 0){
        var trait = {
          code: code,
          dataId: dataId,
          value: value
        }
        if(method == 1){
          this.addTrait(id, trait);
        }
        else if(method == 2){
          this.removeTrait(id, trait);
        }
      }
    }
  }

  Game_Interpreter.prototype.addTrait = function(id, trait){
    $gameActors.actor(id).addTrait(trait);
  }

  Game_Interpreter.prototype.removeTrait = function(id, trait){
    $gameActors.actor(id).removeTrait(trait);
  }

  Game_BattlerBase.prototype.initialize = function(){
    this.initMembers();
    this.initTraits();
  }

  Game_BattlerBase.prototype.initTraits = function(){
    this._traits = [];
  }

  Game_BattlerBase.prototype.allTraits = function(){
    return this._traits.concat(this.traitObjects().reduce(function(r, obj) {
      return r.concat(obj.traits);
    }, []));
  }

  Game_BattlerBase.prototype.addTrait = function(trait){
    var addedTrait = this._traits.filter(function(added){
      return this.isEqualTrait(added, trait);
    }, this);

    if(addedTrait.length == 0){
      this._traits.push(trait);
    }
  }

  Game_BattlerBase.prototype.removeTrait = function(trait){
    var removedTrait = this._traits.filter(function(added){
      return !this.isEqualTrait(added, trait);
    }, this);

    if(removedTrait.length >= 0){
      this._traits = removedTrait;
    }
  }

  Game_BattlerBase.prototype.isEqualTrait = function(a, b){
    return a.code == b.code && a.dataId == b.dataId;
  }
})();
