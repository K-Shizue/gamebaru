//===================================================================
//Title_Menu_Center.js
//タイトル画面とメニュー画面のコマンド文字列配置変更プラグイン
//===================================================================
//Copyright (c) 2017 蔦森くいな
//Released under the MIT license.
//http://opensource.org/licenses/mit-license.php
//-------------------------------------------------------------------
//blog   : http://paradre.com/
//Twitter: https://twitter.com/Kuina_T
//===================================================================
//＜更新情報＞
//　ver1.0.0 2017/06/27 初版
//===================================================================

/*:
 * @plugindesc タイトル画面とメニュー画面のコマンドの文字配置を変更
 * @author 蔦森くいな
 *
 * @help タイトル画面とメニュー画面に表示されるコマンドの文字列を
 * 左揃え、中央揃え、右揃えに変更できます。
 *
 * どの配置にするかプラグイン管理画面のパラメータから設定して下さい。
 * 
 * @param text_align
 * @desc 「left」「center」「right」のうち１つを入力
 * @default center
 * 
 *
 * 利用規約：
 * このプラグインは商用・非商用を問わず無料でご利用いただけます。
 * どのようなゲームに使っても、どのように加工していただいても構いません。
 * MIT Licenseにつき著作権表示とライセンスURLは残しておいて下さい。
 */

(function() {
    
    Window_Command.prototype.itemTextAlign = function() {
        return PluginManager.parameters("Title_Menu_Center")["text_align"];
    };
    
})();