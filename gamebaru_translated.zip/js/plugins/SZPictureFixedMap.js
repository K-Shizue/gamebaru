
//=============================================================================
// SZPictureFixedMap.js
// ----------------------------------------------------------------------------
// Copyright (c) 2018 Suzu
// This software is released under the MIT License.
// http://opensource.org/licenses/mit-license.php
// ----------------------------------------------------------------------------
// Version
// 1.0.0 2018/09/29 初版
//=============================================================================

/*:ja
 * @plugindesc 画像マップ固定プラグイン
 * @author すず
 *
 * @help
 *
 * 表示画像をマップに対して固定できるようになります。
 *
 * 使い方：
 *
 *    プラグインコマンド使用後に通常の画像の表示で画像を表示します。
 *
 *
 *
 * プラグインコマンド：
 *
 *    PictureFixedMap
 *       このプラグインコマンド実行後の画像の表示がマップ固定になります(1回のみ)。
 *
 *    マップに画像を固定
 *       同上
 *
 *
*/

(function(){
  "use strict";


  //=============================================================================
  // Game_Screen
  //  固定用の各種メソッドを追加定義します。
  //=============================================================================
  var _Game_Screen_showPicture = Game_Screen.prototype.showPicture;
  Game_Screen.prototype.showPicture = function(id, name, o, x, y, sx, sy, opacity, blend){
    if(this.isFixedMap()){
      this.pushMapPicture(id, name);
      this.setFixedMap(false);
      x = this.displayPixelX();
      y = this.displayPixelY();
    }
    _Game_Screen_showPicture.call(this, id, name, o, x, y, sx, sy, opacity, blend);
  };

  var _Game_Screen_erasePicture = Game_Screen.prototype.erasePicture;
  Game_Screen.prototype.erasePicture = function(pictureId){
    _Game_Screen_erasePicture.call(this, pictureId);
    this.popMapPicture(pictureId);
  }

  Game_Screen.prototype.pushMapPicture = function(id, name){
    this._fixedPictures[id] = name;
  };

  Game_Screen.prototype.popMapPicture = function(id){
    this._fixedPictures[id] = null;
  };

  Game_Screen.prototype.isFixedMap = function(){
    return this._fixedMap;
  };

  Game_Screen.prototype.setFixedMap = function(bool){
    this._fixedMap = bool;
  };

  Game_Screen.prototype.clearMapPictures = function(){
    this._fixedMap = false;
    this._fixedPictures = [];
  };

  Game_Screen.prototype.displayPixelX = function(){
    return $gameMap.displayX() * $gameMap.tileWidth() * -1;
  }

  Game_Screen.prototype.displayPixelY = function(){
    return $gameMap.displayY() * $gameMap.tileHeight() * -1;;
  }

  Game_Screen.prototype.updateMapPictures = function(){
    var x = this.displayPixelX();
    var y = this.displayPixelY();

    if(!this._fixedPictures){
      this.clearMapPictures();
    }

    this._fixedPictures.map(function(name, index){
      if(name != null){
        var p = this.picture(index);
        this.movePicture(index, 0, x, y, p.scaleX(), p.scaleY(), p.opacity(), p.blendMode(), 1);
      }
    }, this);
  };

  var _Game_Screen_clear = Game_Screen.prototype.clear;
  Game_Screen.prototype.clear = function(){
    _Game_Screen_clear.call(this);
    this.clearMapPictures();
  };

  var _Game_Screen_update = Game_Screen.prototype.update;
  Game_Screen.prototype.update = function(){
    _Game_Screen_update.call(this);
    this.updateMapPictures();
  };


  //=============================================================================
  // Game_Interpreter
  //  プラグインコマンドを追加定義します。
  //=============================================================================
  var _Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
  Game_Interpreter.prototype.pluginCommand = function(command, args) {
    _Game_Interpreter_pluginCommand.apply(this, arguments);

    this.pluginCommandPictureFixedMap(command, args);
  };

  Game_Interpreter.prototype.pluginCommandPictureFixedMap = function(command, args){
    if(command == "PictureFixedMap" || command == "マップに画像を固定"){
      $gameScreen.setFixedMap(true);
    }
  }
})();
