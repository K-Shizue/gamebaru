//=============================================================================
// LoadFadeShorten.js
//=============================================================================
/*:
 * @plugindesc セーブファイルロード時の暗転時間を調節
 * @author uta_asakayu
 * 
 * 
 * @param FadeMultiple
 * @desc フェード(暗転)時間を何倍速にするか
 * @type number
 * @min 0.1
 * @max 48
 * @decimals 2
 * @default 2
 * 
 * @help
 * セーブファイルをロードした時の暗転時間を調節できます。
 * プラグインパラメータ(FadeMultiple)の数値に合わせて、暗転が速くなります。
 * 1未満の数値も入れられます。
 * 48以上の値は意味ないかも。
 * 
 * Scene_Load.prototype.onLoadSuccess
 * を上書きしています。
 * 
 * 共存可能:
 * LoadComSim.js ver1.00
 * https://tm.lucky-duet.com/viewtopic.php?t=3085
 * 
 * ※コードレビュー歓迎します。
 * 
 * https://ci-en.jp/creator/1569
 * 
 */


(function() {
    'use strict';
    function toNumber(str, def) {
        return isNaN(str) ? def : +(str || def);
    };

    var parameters = PluginManager.parameters('LoadFadeShorten');
    const _FadeMultiple = toNumber(parameters['FadeMultiple'], 2)

    Scene_Load.prototype.fadeOutLoad = function() {
        var time = this.slowFadeSpeed() / 60;
        time /= _FadeMultiple
        AudioManager.fadeOutBgm(time);
        AudioManager.fadeOutBgs(time);
        AudioManager.fadeOutMe(time);
        this.startFadeOut(this.slowFadeSpeed() / _FadeMultiple);
    };
    
    Scene_Load.prototype.onLoadSuccess = function() {
        SoundManager.playLoad();
        this.fadeOutLoad();
        this.reloadMapIfUpdated();
        SceneManager.goto(Scene_Map);
        this._loadSuccess = true;
    };


})();
